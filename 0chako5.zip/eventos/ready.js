module.exports = async (bot) => { //faz algo qdo o bot liga
  console.log('!!! estou pronta para ser usada e abusada !!!\n  To de olho em '+bot.channels.cache.size+' canais (chats + calss)');

  const avatares = [
    "https://cdn.discordapp.com/attachments/747639661039714317/749742676152156331/images_9.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/749742676315996190/images_10.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/749669726292148302/download.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/749669341540253756/images_8.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/749669341271949402/images_7.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/749617641211035678/images_4.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531409084678214/images_13.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531409218633769/images_14.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531409407639573/images_15.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531409579343872/images_16.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531446980214945/images_17.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531447344988170/images_18.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531447806361690/images_20.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531447965745212/images_21.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531466076618792/images_22.jpeg",
    "https://cdn.discordapp.com/attachments/747639661039714317/750531466307567636/images_23.jpeg"
  ] 
  
  const status = [
    "online",
    "dnd",
    "idle"
  ]
  
  const atividades = [
     ["Diss pra minha ex!", "LISTENING"],
     ["Free fire", "PLAYING"],
     ["Cade o baiano?", "WATCHING"],
     ["Funk do Deku", "WATCHING"],
     ["Dev=@K1ng#7552", "WATCHING"],
     ["Meu site:https://ochakoururaraka.glitch.me/", "PLAYING"],
    ["Hentai Que fazem sobre mim :(", "WATCHING"]//bot adicionar quantos quiser :V
    ];
  setInterval(async () => { // controlar o intervalo
    let i = Math.floor(Math.random() * atividades.length + 1) - 1
      await bot.user.setActivity(atividades[i][0], { type: atividades [i][1] });
  }, 9000); // intervalo

  setInterval(async () => {
    let b = Math.floor(Math.random() * status.length + 1) - 1
      await bot.user.setStatus(status[b])
  }, 10000)

  setInterval(async () => {
    let c = Math.floor(Math.random() * avatares.length + 1) - 1
      await bot.user.setAvatar(avatares[c])
  }, 50000)

}