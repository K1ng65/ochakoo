const { MessageEmbed } = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "AVISOO!!☡",
  category: "moderation",
  usage: "warn <@usuario> <motivo>",
  description: "Avise alguem quando descrumpri as regras!",
  run: async (client, message, args) => {
    
    if(!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send("Voce precisa ter permissão de Admin para usar este comando!")
    }
    
    const user = message.mentions.members.first()
    
    if(!user) {
      return message.channel.send("Por favor mencione a pessoa que será avisada - warn @usuario <motivo>")
    }
    
    if(message.mentions.users.first().bot) {
      return message.channel.send("Você não pode avisar bot's!")
    }
    
    if(message.author.id === user.id) {
      return message.channel.send("Você não pode avisar a si mesmo")
    }
    
    if(user.id === message.guild.owner.id) {
      return message.channel.send("Seu babaca, você não pode avisar o dono do servidor >:(")
    }
    
    const reason = args.slice(1).join(" ")
    
    if(!reason) {
      return message.channel.send("Por favor forneça um motivo para o aviso - warn @usuario <motivo>")
    }
    
    let warnings = db.get(`warnings_${message.guild.id}_${user.id}`)
    
    if(warnings === 3) {
      return message.channel.send(`${message.mentions.users.first().username} Ele(a) Ja atingiu o limite de 3 avisos!`)
    }
    
    if(warnings === null) {
      db.set(`warnings_${message.guild.id}_${user.id}`, 1)
      user.send(`Voce foi avisado em **${message.guild.name}** por ${reason}`)
      await message.channel.send(`Seu Aviso **${message.mentions.users.first().username}** por ${reason}`)
    } else if(warnings !== null) {
        db.add(`warnings_${message.guild.id}_${user.id}`, 1)
       user.send(`Você foi avisado em **${message.guild.name}** por ${reason}`)
      await message.channel.send(`Seu aviso **${message.mentions.users.first().username}** por ${reason}`)
    }
    
  
  } 
}