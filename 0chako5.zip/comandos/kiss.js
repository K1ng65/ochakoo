const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var gifs = [
  "https://cdn.discordapp.com/attachments/747639661039714317/750488262832947230/anime-kissin-7.gif",
    "https://cdn.discordapp.com/attachments/747639661039714317/750488263352909894/anime-kissin-6.gif",
    "https://cdn.discordapp.com/attachments/747639661039714317/750488264074461265/anime-kissin-3.gif",
    "https://cdn.discordapp.com/attachments/747639661039714317/750488264879767662/anime-kissin-1.gif",
    "https://cdn.discordapp.com/attachments/747639661039714317/750488265714434048/anime-kissin-2.gif",
    "https://cdn.discordapp.com/attachments/747639661039714317/750488266201104545/a34b5dcd20bf9db14c9af93b709bfef3.gif"
];

var aleatorio = gifs[Math.floor(Math.random() * gifs.length)];
let membro = message.mentions.users.first() || args[0];
if (!membro) {
return message.reply('Mencione a pessoa que vc ama');
}
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('BEIJINHO!')
        .setColor('RANDOM')
        .setDescription(`${message.author} Acaba de beijar e expressar seu amor por ${membro}`)
        .setImage(aleatorio)
        .setFooter('FINALMENTE ROLOU UM BEIJINHO!')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}