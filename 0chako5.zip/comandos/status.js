const db = require("quick.db")
const discord = require("discord.js")

module.exports = {
  name: "status",
  description: "Mude o status do bot",
  usage: "status <aqui>",
  category: "owner",
  run: async (client, message, args) => {
    
    //OWNER ONLY COMMAND
    if(!message.author.id === "YOUR ID") {
      return message.channel.send("Esse comando so pode ser usado por donos")
    }
    //ARGUMENT
    if(!args.length) {
      return message.channel.send("Por favor diga a mensagem do status")
    }
    
 db.set(`status`, args.join(" "))
   await message.channel.send("Status do bot atualizado!")
    process.exit(1);
    
  }
}