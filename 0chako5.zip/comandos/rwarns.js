const db = require("quick.db")

module.exports = {
  name: "resetwarns",
  aliases: ["rwarns"],
  usage: "rwarns <@usuario>",
  description: "Resete os avisos da pessoa mencionada",
  run: async (client, message, args) => {
    
    
    if(!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send("Voce não tem perm de adm para usar este comando")
    }
    
    const user = message.mentions.members.first()
    
    if(!user) {
    return message.channel.send("Por favor mencione a pessoa que vai ter seus avisos resetados!")
    }
    
    if(message.mentions.users.first().bot) {
      return message.channel.send("Bot nao pode ter avisos")
    }
    
    if(message.author.id === user.id) {
      return message.channel.send("Voce nao ta permitido resetar seus avisos")
    }
    
    let warnings = db.get(`warnings_${message.guild.id}_${user.id}`)
    
    if(warnings === null) {
      return message.channel.send(`${message.mentions.users.first().username} nao tem mais avisos`)
    }
    
    db.delete(`avisos_${message.guild.id}_${user.id}`)
    user.send(`Seus avisos foram resetados por ${message.author.username} em ${message.guild.name}`)
    await message.channel.send(`Resetado todos avisos do ${message.mentions.users.first().username}`)
    
  
    
}
}