module.exports = {
  name: "unmute",
  category: "moderation",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_ROLES")) {
      return message.channel.send(
        "Você não tem permissao para mutar essa pessoa!"
      );
    }

    if (!message.guild.me.hasPermission("MANAGE_ROLES")) {
      return message.channel.send("Eu nao tenho permissao para gerenciar cargos.");
    }

    const user = message.mentions.members.first();

    if (!user) {
      return message.channel.send(
        "Por favor mencione o membro a ser desmutado"
      );
    }
    
    let muterole = message.guild.roles.cache.find(x => x.name === "Silenciado")
    
    
 if(user.roles.cache.has(muterole)) {
      return message.channel.send("O usuario nao tem tag silenciado")
    }
    
    
    user.roles.remove(muterole)
    
    await message.channel.send(`**${message.mentions.users.first().username}** foi unmuted`)
    
    user.send(`Voce foi desmutado por **${message.guild.name}**`)

  }
};