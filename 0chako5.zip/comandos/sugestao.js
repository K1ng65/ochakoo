const { MessageEmbed } = require("discord.js")


module.exports = {
  name: "SUGESTAO",
  usage: "sugestao <mensagem>",
  description: "Envie sua Sugestão",
  category: "main",
  run: (client, message, args) => {
    
    if(!args.length) {
      return message.channel.send("Por Favor de a sugestão")
    }
    
    let channel = message.guild.channels.cache.find((x) => (x.name === "sugestão" || x.name === "sugestões"))
    
    
    if(!channel) {
      return message.channel.send("Nao existe um canal com nome de - sugestões")
    }
                                                    
    
    let embed = new MessageEmbed()
    .setAuthor("SUGESTÃO: " + message.author.tag, message.author.avatarURL())
    .setThumbnail(message.author.avatarURL())
    .setColor("#ff2050")
    .setDescription(args.join(" "))
    .setTimestamp()
    
    
    channel.send(embed).then(m => {
      m.react("✅")
      m.react("❌")
    })
    

    
    message.channel.send("Enviado sua Sugestão para " + channel)
    
  }
}