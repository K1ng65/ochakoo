const Discord = require("discord.js");

exports.run = (bot, message, args) => {

const embed = new Discord.MessageEmbed()
.setTitle('Declaracao!')
.setColor('RANDOM')
.setDescription('Voce Aceita Namorar comigo?\nEu sou muito fofa\ne muito malvada >:)')
.setImage('https://cdn.discordapp.com/attachments/747639661039714317/749409781495758898/images_5.jpeg');
message.channel.send(embed)
}