const db = require('quick.db')
const Discord = require('discord.js')

exports.run = (bot, message, args) => {
  var classe = [
    'Espadachin',
    'Arqueiro',
    'Suporte',
    'Mago'
  ]
if (!membro) {
   return message.reply('diga a classe que vc escolhe!');
  }
const embed = new Discord.MessageEmbed()
.setTitle('Classe Eacolhida com sucesso!')
.setColor('RANDOM')
.setDescription(`Parabéns Você escolheu sua classe`)
.setFooter('Use' +bot.prefixo+'perfil para ver seu perfil')
message.channel.send(embed)
}