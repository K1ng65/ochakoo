const { MessageEmbed } = require('discord.js');

module.exports = {
  config: {
    name: `clear`,
    aliases: [`purge`, `clear`]
  },
  run: async (bot, message, args) => {
    message.delete()
    if (!message.member.hasPermission(`KICK_MEMBERS`)) return message.reply(`Você não tem permissão para limpar as mensagens.`).then(m => (m.delete({ timeout: 10000 })));
    let clearamount = args[0];
    if (isNaN(clearamount)) return message.reply(`Por favor escolha um numero valido para limpar.`).then(m => (m.delete({ timeout: 10000 })));
    if (clearamount >= 100) clearamount = 99;
    if (clearamount <= 0) return message.reply(`Escolha um numero maior que **0** e menor que **101**`)
    message.channel.send(`⚠ Limpando mensagens aguarde... Aguarde! ⚠️`).then(msg => msg.delete({ timeout: 2000 }));
    setTimeout(async () => {
      await message.channel.bulkDelete(clearamount);
    }, 1000)
  }
}