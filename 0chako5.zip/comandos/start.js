const db = require('quick.db')
const Discord = require('discord.js');

exports.run = (bot, message, args) => {
  
  const embed = new Discord.MessageEmbed()
.setTitle('BEM-VINDO AO INCRIVEL MUNDO\nRPG DA OCHAKO!')
.setColor('RANDOM')
.setDescription('*É AQUI ONDE VOCÊ INICIA SUA JORNADA!!!*\nAqui Comeca sua jornada, ja pode seguir')
.setImage('https://cdn.discordapp.com/attachments/747639661039714317/751098614331473950/78_Sem_Titulo_20200903121650.png')
.setFooter(`Use`+bot.prefixo+`helpRPG para saber informações sobre o rpg!!`);

message.channel.send(embed)
}