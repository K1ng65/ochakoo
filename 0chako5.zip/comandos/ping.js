exports.run = async (client, message, args) => {
  const m = await message.channel.send("Calculando...");
  m.edit(`*COMO ESTA O PING?!*\n<:emoji_6:750553138284462180> latencia é **${m.createdTimestamp - message.createdTimestamp}**ms.\n<:up:750551814994395197> API Latencia é **${Math.round(client.ping)}**ms.`);
}