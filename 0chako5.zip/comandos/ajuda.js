const Discord = require("discord.js")
exports.run = async (bot, message, argumentos, arg_texto, chat) => {
  
  const ajuda = new Discord.MessageEmbed()
    .setColor("GREEN")
    .setTitle("Informações sobre Mim!")
    .setDescription("Olá! Sou Ochako Uraraka\nSou uma Bot de diversão, para saber mais informação reaja aos emotes!\n\n🈶 - Informações\n\n🈴 - Administração\n\n🉐 - Comandos de Diversão")
    .setTimestamp()
    .setFooter(`Comando solicitado por ${message.member.displayName}`, message.author.displayAvatarURL({Size: 32}))   
    
  message.channel.send(ajuda).then(msg => {
    msg.react('🈶').then(r => {
      msg.react('🈴').then(r => {
    msg.react('🉐').then(r => {
      })
    })
  })
    
    const infosFilter = (reaction, user) => reaction.emoji.name === '🈶' && user.id === message.author.id;
        const admFilter = (reaction, user) => reaction.emoji.name === '🈴' && user.id === message.author.id;
    const funFilter = (reaction, user) => reaction.emoji.name === '🉐' && user.id === message.author.id;
    
    const infos = msg.createReactionCollector(infosFilter);
        const adm = msg.createReactionCollector(admFilter);
    const fun = msg.createReactionCollector(funFilter);

    infos.on('collect', r2 => {
      
      ajuda.setTitle("Prazer! Sou O. Uraraka, fui desenvolvida como um passatempo\ne estou sendo feita seriamente agora!\nMeu desenvolvedor K1ng#7552")
      ajuda.setDescription(bot.prefixo+"Ajuda - Mostra os comandos de ajuda!\n"+bot.prefixo+"parceria - Veja as parcerias que estou fazendo!")
      msg.edit(ajuda)
      
    })
    
    adm.on('collect', r2 => {
      
      ajuda.setTitle("Comandos de administração!")
      ajuda.setDescription(bot.prefixo+"ban - Bana um membro!\n"+bot.prefixo+"listban - Veja a lista dos usuários banidos!\n"+bot.prefixo+"unban - Desbana um membro!\n"+bot.prefixo+"anuncio - faça um anúncio em algum canal!\n"+bot.prefixo+"Blist - Veja a lista negrs no seu servidor\n"+bot.prefixo+"Kick - expulse um usuario a balas!\n"+bot.prefixo+"Mute - Faça a pessoa que quebrou as regras pagar!\n"+bot.prefixo+"Unmute - Faça a pessoa que aprendeu sua lição voltar a falar!\n"+bot.prefixo+"warn - avise ao bobao que ele quebrou as regras!\n"+bot.prefixo+"warnings - veja quantos avisos o usuario tem\n"+bot.prefixo+"rwarn - resete os avisos de um usuario!")
      msg.edit(ajuda)
      
    })
    
    fun.on('collect', r2 => {
      
      ajuda.setTitle("Comandos para alegrar seu servidor!")
      ajuda.setDescription(+bot.prefixo+"say - Me faça falar algo!\n"+bot.prefixo+"ship - Veja se seu amor verdadeiro esta no servidor😗\n"+bot.prefixo+"sugestao - dê uma sugestão ao servidor!\n"+bot.prefixo+"kiss - beije alguem!\n"+bot.prefixo+"tapa - bata em alguem\n"+bot.prefixo+"ping - veja meu ping!\n"+bot.prefixo+"avatar - veja a Foto de perfil de um membro!")
      msg.edit(ajuda)
      
    })
  })  
}