const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var gifs = [
    "https://imgur.com/nuaZyQI.gif",
    "https://imgur.com/fwBnpLd.gif",
    "https://imgur.com/MtrHJAj.gif",
    "https://imgur.com/G6Ny8da.gif",
    "https://imgur.com/oaCijYJ.gif"
];

var aleatorio = gifs[Math.floor(Math.random() * gifs.length)];
let membro = message.mentions.users.first() || args[0];
if (!membro) {
return message.reply('Mencione a pessoa que vc odeia para dar um tapao na raba UIIIIS!!');
}
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('TAPAO!')
        .setColor('RANDOM')
        .setDescription(`${message.author} Acaba de dar um *tapao* em ${membro}`)
        .setImage(aleatorio)
        .setFooter('O odio esta no ar')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}