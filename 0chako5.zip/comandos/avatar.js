var user = message.author || message.mentions.member.first()
var avatar = user.displayAvatarURL()

const embed = new Discord.MessageEmbed()
  .setTitle(`Avatar de ${user}`)
  .setImage(avatar)
  message.channel.send(embed)