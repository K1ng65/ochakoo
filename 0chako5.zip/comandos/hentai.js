const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://cdn.discordapp.com/attachments/750570696836382790/750570940437364776/42173.gif',
  'https://cdn.discordapp.com/attachments/750570696836382790/750570940085174292/images_26.jpeg',
  'https://imgur.com/l938lRz.jpeg',
  'https://imgur.com/vIgM6d1.jpeg',
  'https://imgur.com/grsYWXD.jpeg',
  'https://imgur.com/eeU88y9.jpeg'
];

var rand = list[Math.floor(Math.random() * list.length)]
if (message.channel.nsfw == false) {
      return message.channel.send(
        '<:emoji_3:750528153017122918> este não e um canal nsfw!'
      )
}
  const embed = new Discord.MessageEmbed()
        .setTitle('UwU Aqui esta um hentai!!')
        .setColor('RANDOM')
        .setImage(rand)
        .setTimestamp()
        .setFooter('Voce é muito safado? ent use gifhentai para ver um hentai animado UwU!!')
  await message.channel.send(embed);
}