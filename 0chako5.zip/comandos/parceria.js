const Discord = require("discord.js");

exports.run = (bot, message, args) => {

const embed = new Discord.MessageEmbed()
.setTitle('Minhas Parcerias')
.setColor('RANDOM')
.setDescription('[Taiga Aisaka](https://discord.com/api/oauth2/authorize?client_id=733785168212656240&permissions=8&scope=bot)')
.setFooter('Quer Parceria? Fale com ele no privado! K1ng#7552');

message.channel.send(embed)
}