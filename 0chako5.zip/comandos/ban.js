var Discord = require('discord.js');
exports.run = async (bot, message, args) => {
      const prefix = 'o.'

        if(!message.member.hasPermission('BAN_MEMBERS')) return message.reply(`Você não tem permissão para **Ban-Members**`);

        const channel = bot.channels.cache.get(``);//id do canal

        var user = message.mentions.users.first();
        if(!user) return message.reply('Mencione alguem');

        var member;

        try {
          member = await message.guild.members.fetch(user);
        } catch(err) {
          member = null;
        }

        if(member){
          if(member.hasPermission('MANAGE_MESSAGES')) return message.reply('Voce nao pode banir esse membro!!');
        }

        var reason = args.splice(1).join(' ');
        if(!reason) return message.reply('Qual a reação!');

        var log = new Discord.MessageEmbed()
          .setColor('RANDOM')
          .setTitle('Idiota Banido')
          .addField('Membro:', user, true)
          .addField('Banido por:', message.author, true)
          .addField('Motico:', reason)
          .setFooter(`• Author': ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));
        channel.send(log);

        var embed = new Discord.MessageEmbed()
          .setColor('RANDOM')
          .setTitle('Voce foi banido!')
          .addField('Banido Por:', message.author.tag, true)
          .addField('Motivo:', reason, true)
          .setFooter(`• Author: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));

        try {
          await user.send(embed);
        } catch(err) {
          console.warn(err);
        }

        message.guild.members.ban(user); 
        message.channel.send(`**${user}** Foi banido por: **${message.author}**!`);
}