const discord = require("discord.js");

module.exports = {
  name: "kick",
  category: "moderation",
  description: "Expulse alguem com um tiro",
  usage: "kick <@usuario> <motivo>",
  run: (client, message, args) => {
    
    if(!message.member.hasPermission("KICK_MEMBERS")) {
      return message.channel.send(`**${message.author.username}**, Voce nao tem permissão para usar este comando`)
    }
    
    if(!message.guild.me.hasPermission("KICK_MEMBERS")) {
      return message.channel.send(`**${message.author.username}**, Eu não tenho permissao para usar este coman`)
    }
    
    let target = message.mentions.members.first();
    
    if(!target) {
      return message.channel.send(`**${message.author.username}**, Por favor mencione o otario que vai ser expulso a balas`)
    }
    
    if(target.id === message.author.id) {
     return message.channel.send(`**${message.author.username}**, Você não pode se expulsar`)
    }
    
  if(!args[1]) {
    return message.channel.send(`**${message.author.username}**, De um motivo para expulsar`)
  }
    
    let embed = new discord.MessageEmbed()
    .setTitle("Ação: Kick")
    .setDescription(`Expulso ${target} (${target.id})`)
    .setColor("#ff2050")
    .setFooter(`Expulso por ${message.author.username}`);
    
    message.channel.send(embed)
    
    target.kick(args[1]);
    
    
    
  }
}